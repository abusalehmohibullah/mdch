<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FacilitiesImages extends Model
{
    protected $table = 'facilities_images';
    use HasFactory;
}
