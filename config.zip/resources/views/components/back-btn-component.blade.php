<div class="row py-3 mb-3">
    <div class="col-md-12 d-flex">
        <div class="overview-wrap">
            <h3 class="title-1 m-0">{!! nl2br(html_entity_decode($title)) !!}</h3>
        </div>
    </div>
</div>