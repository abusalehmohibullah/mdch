<div class="row py-3 mb-5">
    <div class="col-md-12">
        <div class="overview-wrap">
            <h2 class="title-1">{{$title}}</h2>
            <a href="{{$route}}" class="btn btn-info" role="button" data-bs-toggle="button">
                <i class="{{$icon}}"></i> {{$type}}</a>
        </div>
    </div>
</div>